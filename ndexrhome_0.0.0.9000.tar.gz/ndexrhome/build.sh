#! /bin/zsh

cd /home/fdrennan/Programming/R/ndexr-home
R CMD build .
