styler::style_dir('R')
styler::style_file('app.R')
devtools::install()
